import os
import logging
from typing import Any

import requests
from dotenv import load_dotenv
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import PlainTextResponse

load_dotenv()
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("khoji-ai")
app = FastAPI(title="KHOJI AI Assistant Webhook", version="0.1.0")

VERIFY_TOKEN = os.getenv("VERIFY_TOKEN", "change-me")
WA_TOKEN = os.getenv("WHATSAPP_TOKEN", "")
WA_PHONE_ID = os.getenv("WHATSAPP_PHONE_NUMBER_ID", "")
PAGE_TOKEN = os.getenv("META_PAGE_ACCESS_TOKEN", "")
GRAPH_VERSION = os.getenv("META_GRAPH_VERSION", "v23.0")

# Replace these examples with your current, verified stock/prices before going live.
FAQ = {
    "price": "আমাদের কুর্তির দাম পণ্যভেদে আলাদা। কোন কুর্তিটির ছবি বা নাম পাঠাবেন?",
    "দাম": "আমাদের কুর্তির দাম পণ্যভেদে আলাদা। কোন কুর্তিটির ছবি বা নাম পাঠাবেন?",
    "size": "সাইজ পণ্যভেদে আলাদা। আপনার পছন্দের কুর্তির নাম/ছবি এবং আপনার মাপ জানাবেন?",
    "সাইজ": "সাইজ পণ্যভেদে আলাদা। আপনার পছন্দের কুর্তির নাম/ছবি এবং আপনার মাপ জানাবেন?",
    "delivery": "ডেলিভারি চার্জ এলাকা ও কুরিয়ার অনুযায়ী নিশ্চিত করে জানানো হবে। আপনার জেলা/এলাকা লিখুন।",
    "ডেলিভারি": "ডেলিভারি চার্জ এলাকা ও কুরিয়ার অনুযায়ী নিশ্চিত করে জানানো হবে। আপনার জেলা/এলাকা লিখুন।",
    "order": "অর্ডার করতে পণ্যের নাম/ছবি, সাইজ, আপনার নাম, মোবাইল নম্বর ও সম্পূর্ণ ঠিকানা দিন। অর্ডার নিশ্চিত করার আগে আমরা তথ্য মিলিয়ে নেব।",
    "অর্ডার": "অর্ডার করতে পণ্যের নাম/ছবি, সাইজ, আপনার নাম, মোবাইল নম্বর ও সম্পূর্ণ ঠিকানা দিন। অর্ডার নিশ্চিত করার আগে আমরা তথ্য মিলিয়ে নেব।",
    "cash on delivery": "ক্যাশ অন ডেলিভারি সুবিধা বর্তমানে ওই পণ্যে/এলাকায় আছে কি না অর্ডার নেওয়ার সময় নিশ্চিত করে জানাব।",
    "ক্যাশ অন ডেলিভারি": "ক্যাশ অন ডেলিভারি সুবিধা বর্তমানে ওই পণ্যে/এলাকায় আছে কি না অর্ডার নেওয়ার সময় নিশ্চিত করে জানাব।",
}

def make_reply(message: str) -> str:
    """Safe demo FAQ matching. This is not generative AI; unknown questions go to a human."""
    text = (message or "").strip().lower()
    for key, reply in FAQ.items():
        if key in text:
            return reply
    return "ধন্যবাদ KHOJI Fashion House-এ মেসেজ করার জন্য ❤️ আপনার প্রশ্নটি টিমকে জানানো হবে। একটু সময় দিন, আমরা সঠিক তথ্য দিয়ে উত্তর দেব।"


def send_whatsapp(to: str, body: str) -> None:
    if not WA_TOKEN or not WA_PHONE_ID:
        log.warning("WhatsApp credentials missing; skipped send.")
        return
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{WA_PHONE_ID}/messages"
    response = requests.post(
        url,
        headers={"Authorization": f"Bearer {WA_TOKEN}", "Content-Type": "application/json"},
        json={"messaging_product": "whatsapp", "recipient_type": "individual", "to": to,
              "type": "text", "text": {"preview_url": False, "body": body}},
        timeout=15,
    )
    if not response.ok:
        log.error("WhatsApp send failed: %s %s", response.status_code, response.text[:500])


def send_messenger(recipient_id: str, body: str) -> None:
    if not PAGE_TOKEN:
        log.warning("Messenger Page token missing; skipped send.")
        return
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/me/messages"
    response = requests.post(
        url,
        params={"access_token": PAGE_TOKEN},
        json={"recipient": {"id": recipient_id}, "message": {"text": body}},
        timeout=15,
    )
    if not response.ok:
        log.error("Messenger send failed: %s %s", response.status_code, response.text[:500])


@app.get("/")
def home():
    return {"app": "KHOJI AI Assistant", "status": "running", "mode": "demo FAQ replies"}


@app.get("/webhook", response_class=PlainTextResponse)
def verify_webhook(request: Request):
    # FastAPI's Request query_params are synchronous.
    params = request.query_params
    mode = params.get("hub.mode")
    token = params.get("hub.verify_token")
    challenge = params.get("hub.challenge")
    if mode == "subscribe" and token == VERIFY_TOKEN and challenge:
        return challenge
    raise HTTPException(status_code=403, detail="Webhook verification failed")


@app.post("/webhook")
async def receive_webhook(request: Request):
    data: dict[str, Any] = await request.json()
    try:
        # WhatsApp Cloud API webhook payload
        for entry in data.get("entry", []):
            for change in entry.get("changes", []):
                value = change.get("value", {})
                for msg in value.get("messages", []):
                    if msg.get("type") == "text" and msg.get("from") and msg.get("text", {}).get("body"):
                        sender = msg["from"]
                        reply = make_reply(msg["text"]["body"])
                        send_whatsapp(sender, reply)
            # Messenger Platform webhook payload
            for event in entry.get("messaging", []):
                message = event.get("message", {})
                sender_id = event.get("sender", {}).get("id")
                if sender_id and message.get("text") and not message.get("is_echo"):
                    reply = make_reply(message["text"])
                    send_messenger(sender_id, reply)
    except Exception:
        log.exception("Webhook processing error")
        # Acknowledge to reduce repeated delivery; inspect server logs for failures.
    return {"status": "received"}
