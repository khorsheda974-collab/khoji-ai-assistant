package com.khoji.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { KhojiDashboard() } }
    }
}

@Composable
fun KhojiDashboard() {
    val features = listOf(
        "Facebook Messenger সংযোগ — সেটআপ বাকি",
        "WhatsApp Cloud API — সেটআপ বাকি",
        "পণ্যের দাম ও সাইজ — ডেমো FAQ",
        "অর্ডার সংগ্রহ — পরবর্তী ধাপে",
        "AI মডেল — এখনো সংযুক্ত নয়"
    )
    Scaffold(topBar = { TopAppBarTitle() }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("KHOJI FASHION HOUSE", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("তোমার নিজের অটো-রিপ্লাই অ্যাপের ড্যাশবোর্ড")
                Spacer(Modifier.height(12.dp))
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("স্ট্যাটাস", fontWeight = FontWeight.Bold)
                        Text("ডেমো অ্যাপ চালু আছে; লাইভ মেসেজিং এখনো সংযুক্ত নয়।")
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
            items(features) { feature ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("•", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.width(10.dp))
                        Text(feature)
                    }
                }
            }
            item {
                Spacer(Modifier.height(8.dp))
                Text("নিরাপত্তা: Meta access token বা AI API key কখনো APK-র ভেতরে রাখবে না। এগুলো শুধু নিরাপদ সার্ভারে রাখতে হবে.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarTitle() {
    TopAppBar(title = { Text("KHOJI AI Assistant") })
}
