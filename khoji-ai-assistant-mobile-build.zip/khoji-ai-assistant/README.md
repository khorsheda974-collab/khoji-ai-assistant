# KHOJI AI Assistant — starter project

This is a **starter scaffold**, not a finished live bot. It includes:
- FastAPI webhook server for Meta WhatsApp Cloud API and Facebook Messenger events
- Safe demo FAQ replies for KHOJI Fashion House
- Minimal Android app shell (dashboard/status screen)
- No API keys or Meta tokens included

## Important limits
1. The Android app cannot receive Meta messages by itself. Meta sends webhooks to a public HTTPS server, so the backend must stay online.
2. The demo reply engine is rule-based, not a full generative AI. To use a real AI model, configure a model provider and check its pricing/limits; do not put provider keys in the APK.
3. Meta setup, permissions, business assets and phone/page tokens are required. Do not use unofficial WhatsApp Web automation; it can risk account restrictions.
4. For WhatsApp Cloud API, check current pricing and messaging rules in Meta's official documentation. Testing may use a Meta test number.

## Backend local setup
Requires Python 3.11+.

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn main:app --reload --port 8000
```

Set `VERIFY_TOKEN` in `.env`. For local webhook testing, expose port 8000 using a temporary HTTPS tunnel such as ngrok, then use the HTTPS URL plus `/webhook` in Meta's developer settings. A temporary tunnel is for testing, not production.

## Meta environment variables
- `VERIFY_TOKEN`: any long random string you choose; must match Meta webhook setup.
- `WHATSAPP_TOKEN`: WhatsApp Cloud API access token.
- `WHATSAPP_PHONE_NUMBER_ID`: phone number ID from WhatsApp API setup.
- `META_PAGE_ACCESS_TOKEN`: Facebook Page access token.
- `META_GRAPH_VERSION`: current Graph API version supported by your Meta app (default below may need updating).

Never share tokens or commit `.env` to GitHub.

## Android APK build
Open the `android` folder in Android Studio. Let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK will be under `android/app/build/outputs/apk/debug/`. Android Studio's official instructions: https://developer.android.com/build/build-for-release

The Android app is currently a dashboard shell; it does not yet log in to the backend or display real inbox messages.

## Meta official docs
- WhatsApp Cloud API: https://developers.facebook.com/docs/whatsapp/cloud-api/overview
- Messenger Platform: https://developers.facebook.com/docs/messenger-platform/
- Android APK build: https://developer.android.com/build/build-for-release

## Build APK using only an Android phone (GitHub Actions)
1. Create/sign in to a GitHub account in your phone browser.
2. Create a **public** repository named `khoji-ai-assistant` (public is easiest for free Actions minutes; never upload API keys or customer data).
3. Extract this ZIP with a file manager app, then upload the contents of the `khoji-ai-assistant` folder to the repository, keeping folder paths exactly the same (including `.github/workflows/build-apk.yml`).
4. Open the repository's **Actions** tab. If prompted, enable workflows. Select **Build KHOJI AI Assistant APK** and tap **Run workflow**.
5. When the run finishes successfully, open that run, scroll to **Artifacts**, and download `khoji-ai-assistant-debug-apk`. Extract it to get `app-debug.apk` and install it on your phone (you may need to allow installs from that browser/file manager).

This workflow only builds the starter Android UI. It does **not** make live AI or Facebook/WhatsApp replies work yet. Those need a deployed backend, credentials, Meta app setup and webhook verification. Do not publish access tokens in the GitHub repository.
